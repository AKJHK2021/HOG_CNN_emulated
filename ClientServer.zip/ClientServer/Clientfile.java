import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class FileClient {
	
	private Socket s;
	
	public FileClient(String host, int port, String file,int u_duration) {
		
		try {
			s = new Socket(host, port);
			sendFile(file);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public void sendFile(String file) throws IOException {
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		RandomAccessFile f = new RandomAccessFile("t.jpg", "rw");
           	f.setLength(20 * 1024 * 1024);
		f.close();
		FileInputStream fis = new FileInputStream("t.jpg");
		byte[] buffer = new byte[1024];
		int i = 0;
		long stop;
		stop = System.nanoTime()+ TimeUnit.MILLISECONDS.toNanos(u_duration);
		while ((fis.read(buffer) > 0) && stop>System.nanoTime()) {
			dos.write(buffer);
			System.out.println(i++);
		}
		
		fis.close();
		dos.close();	
	}
	
	public static void main(String[] args) {
		
		FileClient fc = new FileClient("129.97.110.138", 1988, "temp.jpg",7200);
	}

}
